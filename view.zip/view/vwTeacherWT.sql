
create or replace view vwTeacherWT
as select
    oc.ocpk as "과정번호",
    oc.ocname as "과정명",
    oc.regdate as "과정 시작일",
    oc.regdate + crs.crsduration - 1 as "과정 종료일",
    cr.crname as "강의실",
    sub.subname as "과목명",
    ei.wt as "배점"
from
    tblopencourse oc
    inner join tblcourse crs on oc.crspk = crs.crspk
    inner join tblclassroom cr on oc.crpk = cr.crpk
    inner join tblongoingsubject ogs on oc.crspk = ogs.crspk
    inner join tblsubject sub on ogs.subpk = sub.subpk
    left join tblexaminfo ei on sub.subpk = ei.subpk and oc.ocpk = ei.ocpk
    where oc.tpk = <사용자번호>
order by
    oc.ocpk, sub.subname;
    
    select * from vwTeacherWT;
    
    
    
    