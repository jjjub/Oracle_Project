
create or replace view vwStudentComment
as select
    b.boardpk as 글번호,
    b.boardtitle as 제목,
    b.boardpost as 내용,
    cmm.cmmpost as 댓글
from tblBoard b
    inner join tblComment cmm on b.boardpk = cmm.boardpk
    order by b.boardpk;
    
    select * from vwStudentComment;