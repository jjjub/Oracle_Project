
--학생명, 상태, 취직회사명, 재취업지원 신청일, 연장일수, 재취업지원 종료일, 특이사항
create or replace view vwStudentAfter
as select
    u.name as "학생명",
    stusts.stustatus as "상태",
    e.comname as "취직회사명",
    r.regdate as "재취업지원 신청일",
    r.extperiod as "연장일수",
    r.enddate as "재취업지원 종료일",
    r.memo as "특이사항"
from tblstudent stu
    inner join tblUser u on stu.stupk = u.userpk
    inner join tblStudentstatus stusts on stu.stustspk = stusts.stustspk
    inner join tblCourseparticipants cpt on stu.stupk = cpt.stupk
    inner join tblOpenCourse oc on cpt.ocpk = oc.ocpk
    inner join tblCourse crs on oc.crspk = crs.crspk
    inner join tblClassroom cr on oc.crpk = cr.crpk
    left join tblEmployedstd e on stu.stupk = e.stupk
    left join tblResupport r on stu.stupk = r.stupk
    where oc.tpk = <교사번호> and oc.ocpk = <과정번호> and stu.stupk = <학생번호>;

select * from vwStudentAfter;





