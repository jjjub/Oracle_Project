create or replace view vwStudentScore
as select
    sub.subname as 과목명,
    e.expk as 시험번호,
    ei.wt as 배점,
    g.score as 성적,
    u.name as 학생명
from tblGrade g
    inner join tblStudent stu on g.stupk = stu.stupk
    inner join tblExamDone ed on g.edpk = ed.edpk
    inner join tblExam e on ed.expk = e.expk
    inner join tblExamInfo ei on e.exinfopk = ei.exinfopk
    inner join tblSubject sub on ei.subpk = sub.subpk
    inner join tblUser u on stu.stupk = u.userpk
    where stu.stupk = 1
    order by e.expk;

select * from vwStudentScore;



