
-- 과정명, 과정 시작일, 과정 종료일, 강의실명, 수강생 이름
create or replace view vwStudentList
as select
    oc.ocname as "과정명",
    oc.regdate as "과정 시작일",
    oc.regdate + crs.crsduration - 1 as "과정 종료일",
    cr.crname as "강의실명",
    u.name as "수강생 이름"
from tblstudent stu
    inner join tblUser u on stu.stupk = u.userpk
    inner join tblStudentstatus stusts on stu.stustspk = stusts.stustspk
    inner join tblCourseparticipants cpt on stu.stupk = cpt.stupk
    inner join tblOpenCourse oc on cpt.ocpk = oc.ocpk
    inner join tblCourse crs on oc.crspk = crs.crspk
    inner join tblClassroom cr on oc.crpk = cr.crpk
    where oc.tpk = <사용자번호> and oc.ocpk = <과정번호>
    order by oc.regdate, u.name;

select * from vwStudentList;


