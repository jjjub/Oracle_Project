--과목번호, 과목명, 교사명, 배점, 성적, 시험날짜, 시험문제, 작성답안
create or replace view vwStudentExam
as select
    sub.subpk as "과목번호",
    sub.subname as "과목명",
    u.name as "교사명",
    ei.wt as "배점",
    g.score as "성적",
    ei.examdate as "시험날짜",
    e.exam as "시험문제",
    ed.exanswer as "작성답안"
from tblExamInfo ei
    inner join tblSubject sub on ei.subpk = sub.subpk
    inner join tblOpenCourse oc on ei.ocpk = oc.ocpk
    inner join tblUser u on oc.tpk = u.userpk
    inner join tblExam e on e.exinfopk = ei.exinfopk
    inner join tblExamDone ed on e.expk = ed.expk
    inner join tblGrade g on ed.edpk = g.edpk
    inner join tblCourseParticipants cpt on oc.ocpk = cpt.ocpk and ed.stupk = cpt.stupk
    where cpt.stupk = <사용자번호>;

select * from vwStudentExam;








