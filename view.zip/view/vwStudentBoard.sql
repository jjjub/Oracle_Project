--게시판의 게시글을 출력. 글번호, 타입, 등록일, 제목, 내용 출력

create or replace view vwStudentBoard
as select
    b.boardpk as 글번호,
    b.boardtype as 게시판,
    b.regdate as 작성일,
    b.boardtitle as 제목,
    b.boardpost as 내용
from tblBoard b;

select * from vwStudentBoard;





