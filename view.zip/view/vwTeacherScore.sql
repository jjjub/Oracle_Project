

SELECT
    oc.ocpk AS "과정번호",
    oc.ocname AS "과정명",
    oc.regdate AS "과정 시작일",
    oc.regdate + crs.crsduration - 1 AS "과정 종료일",
    cr.crname AS "강의실",
    sub.subname AS "과목명",
    (COUNT(att.attpk) / (SELECT COUNT(DISTINCT attenddate) 
                         FROM tblAttendance 
                         WHERE attenddate BETWEEN oc.regdate AND CURRENT_DATE)) * 100 AS "출석률",
    ei.wt AS "배점",
    u.name AS "교육생 이름",
    g.score AS "교육생 성적"
FROM
    tblOpenCourse oc
    INNER JOIN tblCourse crs ON oc.crspk = crs.crspk
    INNER JOIN tblClassroom cr ON oc.crpk = cr.crpk
    INNER JOIN tblOnGoingSubject ogs ON crs.crspk = ogs.crspk
    INNER JOIN tblSubject sub ON ogs.subpk = sub.subpk
    INNER JOIN tblCourseParticipants cpt ON oc.ocpk = cpt.ocpk
    INNER JOIN tblStudent stu ON cpt.stupk = stu.stupk
    INNER JOIN tblUser u ON stu.stupk = u.userpk
    LEFT JOIN tblExamInfo ei ON sub.subpk = ei.subpk AND oc.ocpk = ei.ocpk
    LEFT JOIN tblExamDone ed ON stu.stupk = ed.stupk AND oc.ocpk = ed.ocpk
    LEFT JOIN tblGrade g ON ed.edpk = g.edpk
    LEFT JOIN tblAttendance att ON stu.stupk = att.stupk AND att.attenddate BETWEEN oc.regdate AND CURRENT_DATE
    where oc.tpk = <사용자번호>
GROUP BY
    oc.ocpk, oc.ocname, oc.regdate, crs.crsduration, cr.crname, sub.subname, ei.wt, u.name, g.score
ORDER BY
    oc.ocpk, sub.subname;




















