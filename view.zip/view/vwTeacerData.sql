
-- 자료번호, 자료명, 자료내용, 등록일
create or replace view vwTeacerData
as select
    datapk as 자료번호,
    datatitle as 자료명,
    datadetail as 자료내용,
    regdate as 등록일
from tblData
    where tpk = <사용자번호>
    order by regdate;
    
select * from vwTeacerData;

















