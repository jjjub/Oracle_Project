
--추천 도서 목록
create or replace view vwBookRecommend
as select bookname from tblBookRecommend;

select * from vwBookRecommend;


