
-- 상담일, 학생명, 상담내용
create or replace view vwTeacherConsulting
as select
    cltdate as 상담일,
    u.name as 학생명,
    cltdiary as 상담내용
from tblConsulting c
    inner join tblTeacher t on c.tpk = t.tpk
    inner join tblUser u on c.stupk = u.userpk
    where t.tpk = <사용자번호>
    order by c.cltdate, u.name;

select * from vwTeacherConsulting;



