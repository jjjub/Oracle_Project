--교육생 이름, 번호, 수강한 과정명, 과정기간(시작 일, 종료일), 강의실

create or replace view vwStudent
as select
    u.name as 이름,
    stu.stupk as 번호,
    oc.ocname as 과정명,
    oc.regdate as 시작일,
    oc.regdate + crs.crsduration - 1 as 종료일,
    cr.crname as 강의실
from tblStudent stu
    inner join tblUser u on stu.stupk = u.userpk
    inner join tblCourseParticipants cpt on stu.stupk = cpt.stupk
    inner join tblOpenCourse oc on cpt.ocpk = oc.ocpk
    inner join tblCourse crs on oc.crspk = crs.crspk
    inner join tblClassroom cr on oc.crpk = cr.crpk
    where stu.stupk = <사용자번호>;
    
    select * from vwStudent;













