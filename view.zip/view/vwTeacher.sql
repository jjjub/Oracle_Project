--교사 이름, 번호, 최근 과정명, 과정상태, 강의실 출력

create or replace view vwTeacher
as select
    tname as "이름",
    tnumber as "번호",
    ocname as "과정명",
    ocstatus as "과정상태",
    classroom as "강의실"
from (
    select
        u.name as tname,
        t.tpk as tnumber,
        oc.ocname as ocname,
        ocs.ocstatus as ocstatus,
        cr.crname as classroom,
        row_number() over(partition by t.tpk order by oc.regdate desc) as rn
    from tblteacher t
    inner join tbluser u on t.tpk = u.userpk
    inner join tblopencourse oc on t.tpk = oc.tpk
    inner join tblopencoursestatus ocs on oc.ocspk = ocs.ocspk
    inner join tblclassroom cr on oc.crpk = cr.crpk
    where t.tpk = <사용자번호>
) where rn = 1;

select * from vwTeacher;








