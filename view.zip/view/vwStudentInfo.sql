--학생 정보 출력
create or replace view vwStudentInfo
as select
    u.userpk as 번호,
    u.name as 이름,
    u.bdate as 생일,
    u.tel as 전화번호,
    u.regdate as 등록일,
    stu.grade as 성적,
    stusts.stustatus as 상태
from tblUser u
    inner join tblStudent stu on u.userpk = stu.stupk
    inner join tblStudentStatus stusts on stu.stustspk = stusts.stustspk
    where stu.stupk = <사용자번호>;
    
    select * from vwStudentInfo;