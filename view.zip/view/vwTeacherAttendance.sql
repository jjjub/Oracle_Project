
-- 과정번호, 과정명, 과정상태, 강의실명, 일자, 학생명, 출결상태
create or replace view vwTeacherAttendance
as select
    oc.ocpk as 과정번호,
    oc.ocname as 과정명,
    ocs.ocstatus as 과정상태,
    cr.crname as 강의실명,
    att.attenddate as 일자,
    u.name as 학생명,
    attsts.attstatus as 출결상태
from tblOpenCourse oc
    inner join tblOpenCourseStatus ocs on oc.ocspk = ocs.ocspk
    inner join tblClassroom cr on oc.crpk = cr.crpk
    inner join tblCourseparticipants cpt on oc.ocpk = cpt.ocpk
    inner join tblUser u on cpt.stupk = u.userpk
    inner join tblAttendance att on u.userpk = att.attpk
    inner join tblAttendStatus attsts on att.attstspk = attsts.attstspk
        where oc.tpk = <사용자번호>
    order by att.attenddate, u.name;


select * from vwTeacherAttendance;


