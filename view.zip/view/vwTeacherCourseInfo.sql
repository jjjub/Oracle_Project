--과정번호, 과정명, 과정기간, 강의실, 등록 인원, 교육생 이름, 전화번호, 등록일, 수료 또는 중도탈락
create or replace view vwTeacherCourseInfo
as select
    rc.ocpk as "과정번호",
    rc.crsname as "과정명",
    rc."과정 시작일",
    rc."과정 종료일",
    rc.crname as "강의실",
    (select count(*) from tblCourseparticipants cpt where cpt.ocpk = rc.ocpk) as "등록 인원",
    u.name as "교육생 이름",
    u.tel as "전화번호",
    u.regdate as "등록일",
    stusts.stustatus as 수료상태
from (
    select
        oc.ocpk,
        crs.crsname,
        oc.regdate as "과정 시작일",
        oc.regdate + crs.crsduration - 1 as "과정 종료일",
        cr.crname,
        oc.tpk as teacher_id,
        oc.ocpk as course_id,
        row_number() over (partition by oc.tpk order by oc.regdate desc) as rn
    from
        tblOpenCourse oc
        inner join tblCourse crs on oc.crspk = crs.crspk
        inner join tblClassroom cr on oc.crpk = cr.crpk
    ) rc
    inner join tblCourseparticipants cpt on rc.course_id = cpt.ocpk
    inner join tblStudent stu on cpt.stupk = stu.stupk
    inner join tblUser u on stu.stupk = u.userpk
    inner join tblStudentStatus stusts on stu.stustspk = stusts.stustspk
    where rc.rn = 1 and rc.teacher_id = <사용자번호>
    order by rc."과정 시작일" desc, rc.crname, u.name;
    
    select * from vwTeacherCourseInfo;