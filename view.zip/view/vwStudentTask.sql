--과제번호, 교사명, 과제내용, 작성답안
create or replace view vwStudentTask
as select
    ts.tspk as "과제번호",
    u.name as "교사명",
    task.task as "과제내용",
    ts.tsanswer as "작성답안"
from tblTask task
    inner join tblTaskSubmit ts on task.taskpk = ts.taskpk
    inner join tblCourseParticipants cpt on ts.stupk = cpt.stupk and ts.ocpk = cpt.ocpk
    inner join tblOpenCourse oc on cpt.ocpk = oc.ocpk
    inner join tblUser u on oc.tpk = u.userpk
    where cpt.stupk = <학생번호>;

select * from vwStudentTask;








