
create or replace procedure procStudentScore (
    pstupk number,
    psubname varchar2
)
is
    vfound boolean := false; --검색 결과 유무 확인
begin
    for r in (
    select sub.subname, e.expk, ei.wt, g.score, u.name
from tblGrade g
    inner join tblStudent stu on g.stupk = stu.stupk
    inner join tblExamDone ed on g.edpk = ed.edpk
    inner join tblExam e on ed.expk = e.expk
    inner join tblExamInfo ei on e.exinfopk = ei.exinfopk
    inner join tblSubject sub on ei.subpk = sub.subpk
    inner join tblUser u on stu.stupk = u.userpk
    where stu.stupk = pstupk and upper(sub.subname) like upper('%'||psubname||'%')
    order by e.expk
    )
    loop
    vfound := true;
    dbms_output.put_line('과목명: '||r.subname || ', 시험번호: '||r.expk || ', 배점: '||r.wt || ', 점수: '||r.score || ', 학생명: '||r.name);
    end loop;
    
    -- 검색 결과가 없을 경우
    if not vfound then
        dbms_output.put_line('검색 결과가 없습니다.');
    end if;
    
    -- 에러 처리
exception
    when others then
        -- 에러 메시지
        dbms_output.put_line('에러: ' || sqlerrm);

end procStudentScore;
/

begin
    procStudentScore(1, '자바');
end;
/



