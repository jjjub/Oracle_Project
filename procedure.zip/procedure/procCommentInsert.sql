create or replace procedure procCommentInsert (
    pcmmpost tblComment.cmmpost%type,
    puserpk tblBoard.userpk%type,
    pboardpk tblBoard.boardpk%type
) is
begin
    insert into tblComment (cmmpk, cmmpost, userpk, boardpk)
    values ((select nvl(max(cmmpk), 0) + 1 from tblComment), pcmmpost, puserpk, pboardpk);
    
    --커밋
    commit;
    
    dbms_output.put_line('댓글이 성공적으로 등록되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('댓글 등록 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
end procCommentInsert;
/

begin
    procCommentInsert('댓글', 210, 18);
end;
/

select * from tblcomment order by cmmpk desc;


