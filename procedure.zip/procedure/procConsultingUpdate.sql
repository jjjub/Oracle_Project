create or replace procedure procConsultingUpdate (
    pcltdiary varchar2,
    pcltpk number,
    ptpk number,
    pstupk number
) is
begin
    update tblConsulting set cltdiary = pcltdiary
    where cltpk = pcltpk and tpk = ptpk and stupk = pstupk;
    
    --커밋
    commit;
    
    dbms_output.put_line('상담일지가 성공적으로 수정되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('상담일지 수정 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
        
end procConsultingUpdate;
/

begin
    procConsultingUpdate('상담일지수정', 31, 212, 1);
end;
/

