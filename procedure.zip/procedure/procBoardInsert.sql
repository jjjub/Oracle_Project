create or replace procedure procBoardInsert (
    pboardtype tblBoard.boardtype%type,
    pregdate tblBoard.regdate%type,
    pboardtitle tblBoard.boardtitle%type,
    pboardpost tblBoard.boardpost%type,
    puserpk tblBoard.userpk%type
) is
begin
    insert into tblboard (boardpk, boardtype, regdate, boardtitle, boardpost, userpk)
    values ((select nvl(max(boardpk), 0) + 1 from tblBoard), pboardtype, pregdate, pboardtitle, pboardpost, puserpk);
    
    --커밋
    commit;
    
    dbms_output.put_line('게시글이 성공적으로 등록되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('게시글 등록 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
end procBoardInsert;
/

begin
    procBoardInsert('자유게시판', sysdate, '제목', '내용', 1);
end;
/



