create or replace procedure procDataSearch (
    psearch in varchar2
)
is
vfound boolean := false; --검색 결과 유무 확인
begin
    -- 검색어를 대소문자에 구분 없이 검색
    for result in (
        select datapk, datatitle, datadetail
        from tbldata
        where upper(datatitle) like upper('%' || psearch || '%')
        or upper(datadetail) like upper('%' || psearch || '%')
        order by datapk
    )
    loop
    vfound := true; --검색 결과 존재
    -- 검색된 데이터 출력
        dbms_output.put_line('자료번호: ' || result.datapk || ', 제목: ' || result.datatitle || ', 내용: ' || result.datadetail);
    end loop;
    
    -- 검색 결과가 없을 경우
    if not vfound then
        dbms_output.put_line('검색 결과가 없습니다.');
    end if;
    
    -- 에러 처리
exception
    when others then
        -- 에러 메시지
        dbms_output.put_line('에러: ' || sqlerrm);
end procDataSearch;
/

begin
    procDataSearch('sql');
end;
/




