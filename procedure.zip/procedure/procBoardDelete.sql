create or replace procedure procBoardDelete (
    pboardpk tblBoard.boardpk%type,
    puserpk tblBoard.userpk%type
) is
begin
    delete tblBoard
    where boardpk = pboardpk and userpk = puserpk;
    
    --커밋
    commit;
    
    dbms_output.put_line('게시글이 성공적으로 삭제되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('게시글 삭제 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
end procBoardDelete;
/

begin
    procBoardDelete(20, 1);
end;
/



