create or replace procedure procCommentDelete (
    pcmmpk tblComment.cmmpk%type,
    puserpk tblComment.userpk%type
) is
begin
    delete tblComment
    where cmmpk = pcmmpk and userpk = puserpk;
    
    --커밋
    commit;
    
    dbms_output.put_line('댓글이 성공적으로 삭제되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('댓글 삭제 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
end procCommentDelete;
/

begin
    procCommentDelete(19, 210);
end;
/


