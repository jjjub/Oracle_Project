create or replace procedure procStudentExam (
    pexpk in number,            -- 시험번호
    pnewexanswer in varchar2,   -- 새 답안
    pstupk in number            -- 학생번호
) is
    -- 조회된 데이터를 임시로 저장할 변수
    vsubpk number;
    vsubname varchar2(100);
    vtname varchar2(100);
    vwt number;
    vscore number;
    vexamdate date;
    vexam varchar2(4000);
    voldexanswer varchar2(4000);
begin
    -- 시험 정보와 학생에 대한 정보를 조회
    select sub.subpk, sub.subname, u.name, ei.wt, g.score, ei.examdate, e.exam, ed.exanswer
    into vsubpk, vsubname, vtname, vwt, vscore, vexamdate, vexam, voldexanswer
    from tblExamInfo ei
    inner join tblSubject sub on ei.subpk = sub.subpk
    inner join tblOpenCourse oc on ei.ocpk = oc.ocpk
    inner join tblUser u on oc.tpk = u.userpk
    inner join tblExam e on e.exinfopk = ei.exinfopk
    inner join tblExamDone ed on e.expk = ed.expk and ed.stupk = pstupk
    inner join tblGrade g on ed.edpk = g.edpk and g.stupk = pstupk
    inner join tblCourseParticipants cpt on oc.ocpk = cpt.ocpk and cpt.stupk = pstupk
    where e.expk = pexpk and ed.stupk = pstupk
    and rownum = 1; -- 한 행만 반환

    -- 조회된 정보를 출력
    dbms_output.put_line('과목번호: ' || vsubpk);
    dbms_output.put_line('과목명: ' || vsubname);
    dbms_output.put_line('교사명: ' || vtname);
    dbms_output.put_line('배점: ' || vwt);
    dbms_output.put_line('시험날짜: ' || to_char(vexamdate, 'YYYY-MM-DD'));
    dbms_output.put_line('시험문제: ' || vexam);
    dbms_output.put_line('작성답안: ' || voldexanswer);
    dbms_output.put_line('점수: ' || vscore);

    -- 작성답안을 새로운 답안으로 업데이트
    update tblExamDone
    set exanswer = pnewexanswer
    where expk = pexpk and stupk = pstupk;

    -- 업데이트 성공 메시지를 출력
    dbms_output.put_line('작성답안이 성공적으로 업데이트 되었습니다.');

    -- 커밋
    commit;

exception
    when no_data_found then
        dbms_output.put_line('조회된 시험 정보가 없습니다.');
    when others then
        dbms_output.put_line('오류: ' || sqlerrm);
        -- 실패시 롤백
        rollback;
end procStudentExam;
/

begin
    procStudentExam(1, 'abstract',1);
end;
/

