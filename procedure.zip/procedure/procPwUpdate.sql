
create or replace procedure procPwUpdate (
    pstupk number,
    pnewpw varchar2
)
is
begin
    update tblUser set pw = pnewpw where userpk = pstupk;
    
    -- 에러 처리
exception
    when others then
        -- 에러 메시지
        dbms_output.put_line('에러: ' || sqlerrm);
        
end procPwUpdate;
/

begin
    procPwUpdate(1, '2886781');
end;
/











