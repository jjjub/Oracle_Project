create or replace procedure procConsultingDelete (
    pcltpk number,
    ptpk number
) is
begin
    delete tblConsulting where cltpk = pcltpk and tpk = ptpk;
    
    --커밋
    commit;
    
    dbms_output.put_line('상담일지가 성공적으로 삭제되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('상담일지 삭제 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
        
end procConsultingDelete;
/

begin
    procConsultingDelete(31, 212);
end;
/

