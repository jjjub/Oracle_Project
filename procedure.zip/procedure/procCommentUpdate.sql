create or replace procedure procCommentUpdate (
    pcmmpost tblComment.cmmpost%type,
    pcmmpk tblComment.cmmpk%type,
    puserpk tblBoard.userpk%type,
    pboardpk tblBoard.boardpk%type
) is
begin
    update tblComment
    set
    cmmpost = pcmmpost
    where cmmpk = pcmmpk and userpk = puserpk and boardpk = pboardpk;
    
    --커밋
    commit;
    
    dbms_output.put_line('댓글이 성공적으로 수정되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('댓글 수정 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
end procCommentUpdate;
/

begin
    procCommentUpdate('댓글수정2', 20, 210, 18);
end;
/



