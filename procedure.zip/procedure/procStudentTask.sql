create or replace procedure procStudentTask (
    ptaskpk in number,          -- 과제번호
    pnewtsanswer in varchar2,   -- 새 답안
    pstupk in number            -- 학생번호
) is
    -- 조회된 데이터를 임시로 저장할 변수
    vtaskpk number;
    vtname varchar2(100);
    vtask tblTask.task%type;
    vtsanswer tblTaskSubmit.tsanswer%type;
begin
    -- 시험 정보와 학생에 대한 정보를 조회
    select task.taskpk, u.name, task.task, ts.tsanswer
    into vtaskpk, vtname, vtask, vtsanswer
    from tblTask task
    inner join tblTaskSubmit ts on task.taskpk = ts.taskpk
    inner join tblCourseParticipants cpt on ts.stupk = cpt.stupk and ts.ocpk = cpt.ocpk
    inner join tblOpenCourse oc on cpt.ocpk = oc.ocpk
    inner join tblUser u on oc.tpk = u.userpk
    where cpt.stupk = pstupk and task.taskpk = ptaskpk;

    -- 조회된 정보를 출력
    dbms_output.put_line('과제번호: ' || vtaskpk);
    dbms_output.put_line('교사명: ' || vtname);
    dbms_output.put_line('과제: ' || vtask);
    dbms_output.put_line('작성답안: ' || vtsanswer);

    -- 작성답안을 새로운 답안으로 업데이트
    update tblTaskSubmit
    set tsanswer = pnewtsanswer
    where taskpk = ptaskpk and stupk = pstupk;

    -- 업데이트 성공 메시지를 출력
    dbms_output.put_line('작성답안이 성공적으로 업데이트 되었습니다.');

    -- 커밋
    commit;

exception
    when no_data_found then
        dbms_output.put_line('조회된 과제 정보가 없습니다.');
    when others then
        dbms_output.put_line('오류: ' || sqlerrm);
        -- 실패시 롤백
        rollback;
end procStudentTask;
/

begin
    procStudentTask(1, '자바의 핵심 원리를 명확하게 이해할 수 있었다.',6);
end;
/





