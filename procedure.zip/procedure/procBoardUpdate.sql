create or replace procedure procBoardUpdate (
    pboardpk tblBoard.boardpk%type,
    pboardtype tblBoard.boardtype%type,
    pboardtitle tblBoard.boardtitle%type,
    pboardpost tblBoard.boardpost%type,
    puserpk tblBoard.userpk%type
) is
begin
    update tblBoard
    set
    boardtype = pboardtype, regdate = sysdate, boardtitle = pboardtitle, boardpost = pboardpost
    where boardpk = pboardpk and userpk = puserpk;
    
    --커밋
    commit;
    
    dbms_output.put_line('게시글이 성공적으로 수정되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('게시글 수정 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
end procBoardUpdate;
/

begin
    procBoardUpdate(20, '자유게시판', '제목', '내용수정', 1);
end;
/


