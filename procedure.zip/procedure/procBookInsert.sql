create or replace procedure procBookInsert (
    pbookname varchar2,
    ptpk number
) is
begin
    insert into tblBookRecommend (br, regdate, bookname, tpk)
    values ((select nvl(max(br), 0) + 1 from tblBookRecommend), sysdate, pbookname, ptpk);
    
    --커밋
    commit;
    
    dbms_output.put_line('도서가 성공적으로 등록되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('도서 등록 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
        
end procBookInsert;
/

begin
    procBookInsert('자바의 정석', 212);
end;
/

