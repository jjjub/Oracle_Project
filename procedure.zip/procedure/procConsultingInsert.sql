create or replace procedure procConsultingInsert (
    pcltdiary varchar2,
    ptpk number,
    pstupk number
) is
begin
    insert into tblConsulting (cltpk, cltdate, cltdiary, tpk, stupk)
    values ((select nvl(max(cltpk), 0) + 1 from tblConsulting), sysdate, pcltdiary, ptpk, pstupk);
    
    --커밋
    commit;
    
    dbms_output.put_line('상담일지가 성공적으로 등록되었습니다.');
    
    --예외 처리
exception
    when others then
        dbms_output.put_line('상담일지 등록 중 오류가 발생했습니다: ' || sqlerrm);
        --실패 시 롤백
        rollback;
        
end procConsultingInsert;
/

begin
    procConsultingInsert('상담일지등록', 212, 1);
end;
/

