--프리시저
--특정 교육생 정보 출력시 교육생 이름, 생년월일 , 주민번호 뒷자리, 전화번호, 등록일, 수강 과정명, 담당 강사,수강상태(수강예정/수강중/수료/중도탈락),상담일지내용을 출력한다
CREATE OR REPLACE PROCEDURE procSearchStudent(
    pname varchar2
)
is
    name tblUser.name%type;
    pssn tblUser.ssn%type;
    ptel tblUser.tel%type;
    pRegdate tblUser.regdate%type;
    pocname tblOpenCourse.ocname%type;
    pteacher tblUser.name%type;
    pStustatus tblStudentStatus.stustatus%type;
    pcltdiary tblConsulting.cltdiary%type;
begin
    select u.name, u.ssn, u.tel, u.Regdate, o.ocname, t.tname, ss.stustatus, cs.cltdiary into name, pssn, ptel, pregdate, pocname, pteacher, pstustatus, pcltdiary 
        from tblUser u 
            right outer join 
            tblStudent s
                on u.userpk = s.stupk
                   right outer join 
                    tblCourseParticipants c
                        on c.stupk = s.stupk
                            left outer join
                                tblOpenCourse o
                                    on o.ocpk = c.ocpk
                                        left outer join
                                            (select u.name as tname, t.tpk from tblUser u left outer join tblTeacher t on u.userpk = t.tpk) t
                                                on o.tpk = t.tpk
                                                    left outer join 
                                                        tblConsulting cs
                                                            on c.stupk = cs.stupk
                                                                left outer join 
                                                                    tblStudentStatus ss
                                                                        on s.stustspk = ss.stustspk
                                                                            where name = pname;
    dbms_output.put_line(' | 이름 |' || '     | 전화번호 |     ' ||'|생년월일|'||'   '||'|주민등록번호 뒷자리|'||'     '  ||'|등록일|'||'                                '|| '| 과정명 |'|| '                             ' ||'|담당교사|' ||'           '|| '| 학생상태 |' || '         | 상담일지내용 |');
    dbms_output.put_line('-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------');
    dbms_output.put_line(' '||name ||'       '|| ptel ||'       '||substr(pssn, 1, 6)||'           '||substr(pssn, 8, 15)||'             '||pregdate||'                    ' ||pocname ||'        '|| pteacher ||'                '|| pStuStatus ||pcltdiary||'                  ' );
--     name, pbirth, ptel, pregdate, pocname, pteacher, pstustatus, pcltdiary 
end procSearchStudent;
/

begin
     procSearchStudent('백은현');
end;
/


